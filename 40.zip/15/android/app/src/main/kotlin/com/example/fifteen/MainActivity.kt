package com.example.fifteen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
